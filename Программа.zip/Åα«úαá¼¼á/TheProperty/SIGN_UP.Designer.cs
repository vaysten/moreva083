﻿namespace TheProperty
{
    partial class SIGN_UP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SIGN_UP));
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.btnClose = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaElipse2 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.Label = new Guna.UI.WinForms.GunaLabel();
            this.panelInfo = new System.Windows.Forms.Panel();
            this.labelMessenge = new System.Windows.Forms.Label();
            this.gunaPictureBox = new Guna.UI.WinForms.GunaPictureBox();
            this.TextBoxPassword = new Guna.UI.WinForms.GunaTextBox();
            this.TextBoxUsername = new Guna.UI.WinForms.GunaTextBox();
            this.btnSignUP = new Guna.UI.WinForms.GunaAdvenceButton();
            this.TextBoxSurname = new Guna.UI.WinForms.GunaTextBox();
            this.TextBoxName = new Guna.UI.WinForms.GunaTextBox();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel1.SuspendLayout();
            this.panelInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.TargetControl = this;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.White;
            this.gunaLabel1.Location = new System.Drawing.Point(8, 101);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(17, 23);
            this.gunaLabel1.TabIndex = 0;
            this.gunaLabel1.Text = "S";
            this.gunaLabel1.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel4.ForeColor = System.Drawing.Color.White;
            this.gunaLabel4.Location = new System.Drawing.Point(8, 154);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(17, 23);
            this.gunaLabel4.TabIndex = 3;
            this.gunaLabel4.Text = "N";
            this.gunaLabel4.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel3.ForeColor = System.Drawing.Color.White;
            this.gunaLabel3.Location = new System.Drawing.Point(7, 135);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(17, 23);
            this.gunaLabel3.TabIndex = 2;
            this.gunaLabel3.Text = "G";
            this.gunaLabel3.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // btnClose
            // 
            this.btnClose.AnimationHoverSpeed = 0.07F;
            this.btnClose.AnimationSpeed = 0.03F;
            this.btnClose.BaseColor = System.Drawing.Color.White;
            this.btnClose.BorderColor = System.Drawing.Color.White;
            this.btnClose.CheckedBaseColor = System.Drawing.Color.White;
            this.btnClose.CheckedBorderColor = System.Drawing.Color.White;
            this.btnClose.CheckedForeColor = System.Drawing.Color.White;
            this.btnClose.CheckedImage = ((System.Drawing.Image)(resources.GetObject("btnClose.CheckedImage")));
            this.btnClose.CheckedLineColor = System.Drawing.Color.White;
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnClose.FocusedColor = System.Drawing.Color.Empty;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.ImageSize = new System.Drawing.Size(20, 20);
            this.btnClose.LineColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(186, 2);
            this.btnClose.Name = "btnClose";
            this.btnClose.OnHoverBaseColor = System.Drawing.Color.White;
            this.btnClose.OnHoverBorderColor = System.Drawing.Color.White;
            this.btnClose.OnHoverForeColor = System.Drawing.Color.White;
            this.btnClose.OnHoverImage = null;
            this.btnClose.OnHoverLineColor = System.Drawing.Color.White;
            this.btnClose.OnPressedColor = System.Drawing.Color.White;
            this.btnClose.Size = new System.Drawing.Size(44, 34);
            this.btnClose.TabIndex = 43;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel6.ForeColor = System.Drawing.Color.White;
            this.gunaLabel6.Location = new System.Drawing.Point(8, 202);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(17, 23);
            this.gunaLabel6.TabIndex = 4;
            this.gunaLabel6.Text = "N";
            this.gunaLabel6.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.Black;
            this.gunaPanel1.Controls.Add(this.gunaLabel8);
            this.gunaPanel1.Controls.Add(this.gunaLabel7);
            this.gunaPanel1.Controls.Add(this.gunaLabel6);
            this.gunaPanel1.Controls.Add(this.gunaLabel4);
            this.gunaPanel1.Controls.Add(this.gunaLabel3);
            this.gunaPanel1.Controls.Add(this.gunaLabel2);
            this.gunaPanel1.Controls.Add(this.gunaLabel1);
            this.gunaPanel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel1.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(32, 349);
            this.gunaPanel1.TabIndex = 45;
            this.gunaPanel1.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel8.ForeColor = System.Drawing.Color.White;
            this.gunaLabel8.Location = new System.Drawing.Point(5, 225);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(29, 23);
            this.gunaLabel8.TabIndex = 6;
            this.gunaLabel8.Text = "<-";
            this.gunaLabel8.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel7.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel7.ForeColor = System.Drawing.Color.White;
            this.gunaLabel7.Location = new System.Drawing.Point(11, 185);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(13, 23);
            this.gunaLabel7.TabIndex = 5;
            this.gunaLabel7.Text = "I";
            this.gunaLabel7.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI Semibold", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel2.ForeColor = System.Drawing.Color.White;
            this.gunaLabel2.Location = new System.Drawing.Point(9, 118);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(14, 23);
            this.gunaLabel2.TabIndex = 1;
            this.gunaLabel2.Text = "I";
            this.gunaLabel2.Click += new System.EventHandler(this.gunaLabel8_Click);
            // 
            // gunaElipse2
            // 
            this.gunaElipse2.Radius = 15;
            this.gunaElipse2.TargetControl = this;
            // 
            // Label
            // 
            this.Label.AutoSize = true;
            this.Label.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Label.Location = new System.Drawing.Point(57, 34);
            this.Label.Name = "Label";
            this.Label.Size = new System.Drawing.Size(113, 25);
            this.Label.TabIndex = 46;
            this.Label.Text = "Регистрация";
            this.Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelInfo
            // 
            this.panelInfo.Controls.Add(this.labelMessenge);
            this.panelInfo.Controls.Add(this.gunaPictureBox);
            this.panelInfo.Location = new System.Drawing.Point(11, 247);
            this.panelInfo.Name = "panelInfo";
            this.panelInfo.Size = new System.Drawing.Size(213, 19);
            this.panelInfo.TabIndex = 52;
            this.panelInfo.Visible = false;
            // 
            // labelMessenge
            // 
            this.labelMessenge.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelMessenge.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelMessenge.Location = new System.Drawing.Point(18, 0);
            this.labelMessenge.Name = "labelMessenge";
            this.labelMessenge.Size = new System.Drawing.Size(195, 19);
            this.labelMessenge.TabIndex = 1;
            this.labelMessenge.Text = "Messeng";
            this.labelMessenge.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // gunaPictureBox
            // 
            this.gunaPictureBox.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox.Image")));
            this.gunaPictureBox.Location = new System.Drawing.Point(0, 0);
            this.gunaPictureBox.Name = "gunaPictureBox";
            this.gunaPictureBox.Size = new System.Drawing.Size(19, 19);
            this.gunaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox.TabIndex = 0;
            this.gunaPictureBox.TabStop = false;
            // 
            // TextBoxPassword
            // 
            this.TextBoxPassword.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxPassword.BaseColor = System.Drawing.Color.White;
            this.TextBoxPassword.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxPassword.BorderSize = 1;
            this.TextBoxPassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPassword.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxPassword.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxPassword.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxPassword.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxPassword.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TextBoxPassword.Location = new System.Drawing.Point(11, 207);
            this.TextBoxPassword.MaxLength = 30;
            this.TextBoxPassword.Name = "TextBoxPassword";
            this.TextBoxPassword.PasswordChar = '•';
            this.TextBoxPassword.Radius = 13;
            this.TextBoxPassword.Size = new System.Drawing.Size(210, 35);
            this.TextBoxPassword.TabIndex = 50;
            this.TextBoxPassword.Text = "Password";
            this.TextBoxPassword.Enter += new System.EventHandler(this.TextBoxPassword_Enter);
            this.TextBoxPassword.Leave += new System.EventHandler(this.TextBoxPassword_Leave);
            // 
            // TextBoxUsername
            // 
            this.TextBoxUsername.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxUsername.BaseColor = System.Drawing.Color.White;
            this.TextBoxUsername.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxUsername.BorderSize = 1;
            this.TextBoxUsername.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxUsername.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxUsername.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxUsername.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxUsername.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxUsername.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TextBoxUsername.Location = new System.Drawing.Point(11, 166);
            this.TextBoxUsername.MaxLength = 30;
            this.TextBoxUsername.Name = "TextBoxUsername";
            this.TextBoxUsername.PasswordChar = '\0';
            this.TextBoxUsername.Radius = 13;
            this.TextBoxUsername.Size = new System.Drawing.Size(210, 35);
            this.TextBoxUsername.TabIndex = 49;
            this.TextBoxUsername.Text = "Username";
            this.TextBoxUsername.Enter += new System.EventHandler(this.TextBoxUsername_Enter);
            this.TextBoxUsername.Leave += new System.EventHandler(this.TextBoxUsername_Leave);
            // 
            // btnSignUP
            // 
            this.btnSignUP.AnimationHoverSpeed = 0.07F;
            this.btnSignUP.AnimationSpeed = 0.03F;
            this.btnSignUP.BackColor = System.Drawing.Color.Transparent;
            this.btnSignUP.BaseColor = System.Drawing.Color.Black;
            this.btnSignUP.BorderColor = System.Drawing.Color.Black;
            this.btnSignUP.CheckedBaseColor = System.Drawing.Color.Gray;
            this.btnSignUP.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnSignUP.CheckedForeColor = System.Drawing.Color.White;
            this.btnSignUP.CheckedImage = ((System.Drawing.Image)(resources.GetObject("btnSignUP.CheckedImage")));
            this.btnSignUP.CheckedLineColor = System.Drawing.Color.DimGray;
            this.btnSignUP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignUP.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnSignUP.FocusedColor = System.Drawing.Color.Empty;
            this.btnSignUP.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSignUP.ForeColor = System.Drawing.Color.White;
            this.btnSignUP.Image = null;
            this.btnSignUP.ImageSize = new System.Drawing.Size(20, 20);
            this.btnSignUP.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSignUP.Location = new System.Drawing.Point(49, 292);
            this.btnSignUP.Name = "btnSignUP";
            this.btnSignUP.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.btnSignUP.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnSignUP.OnHoverForeColor = System.Drawing.Color.White;
            this.btnSignUP.OnHoverImage = null;
            this.btnSignUP.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSignUP.OnPressedColor = System.Drawing.Color.Black;
            this.btnSignUP.Radius = 15;
            this.btnSignUP.Size = new System.Drawing.Size(131, 30);
            this.btnSignUP.TabIndex = 51;
            this.btnSignUP.Text = "SIGN UP";
            this.btnSignUP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnSignUP.Click += new System.EventHandler(this.btnSignUP_Click);
            // 
            // TextBoxSurname
            // 
            this.TextBoxSurname.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxSurname.BaseColor = System.Drawing.Color.White;
            this.TextBoxSurname.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxSurname.BorderSize = 1;
            this.TextBoxSurname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxSurname.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxSurname.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxSurname.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxSurname.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxSurname.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TextBoxSurname.Location = new System.Drawing.Point(11, 125);
            this.TextBoxSurname.MaxLength = 30;
            this.TextBoxSurname.Name = "TextBoxSurname";
            this.TextBoxSurname.PasswordChar = '\0';
            this.TextBoxSurname.Radius = 13;
            this.TextBoxSurname.Size = new System.Drawing.Size(210, 35);
            this.TextBoxSurname.TabIndex = 48;
            this.TextBoxSurname.Text = "Surname";
            this.TextBoxSurname.Enter += new System.EventHandler(this.TextBoxSurname_Enter);
            this.TextBoxSurname.Leave += new System.EventHandler(this.TextBoxSurname_Leave);
            // 
            // TextBoxName
            // 
            this.TextBoxName.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxName.BaseColor = System.Drawing.Color.White;
            this.TextBoxName.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxName.BorderSize = 1;
            this.TextBoxName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxName.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxName.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxName.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxName.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxName.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.TextBoxName.Location = new System.Drawing.Point(11, 84);
            this.TextBoxName.MaxLength = 30;
            this.TextBoxName.Name = "TextBoxName";
            this.TextBoxName.PasswordChar = '\0';
            this.TextBoxName.Radius = 13;
            this.TextBoxName.Size = new System.Drawing.Size(210, 35);
            this.TextBoxName.TabIndex = 47;
            this.TextBoxName.Text = "Name";
            this.TextBoxName.Enter += new System.EventHandler(this.TextBoxName_Enter);
            this.TextBoxName.Leave += new System.EventHandler(this.TextBoxName_Leave);
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.Controls.Add(this.Label);
            this.gunaPanel2.Controls.Add(this.panelInfo);
            this.gunaPanel2.Controls.Add(this.btnClose);
            this.gunaPanel2.Controls.Add(this.TextBoxPassword);
            this.gunaPanel2.Controls.Add(this.TextBoxName);
            this.gunaPanel2.Controls.Add(this.TextBoxUsername);
            this.gunaPanel2.Controls.Add(this.TextBoxSurname);
            this.gunaPanel2.Controls.Add(this.btnSignUP);
            this.gunaPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gunaPanel2.Location = new System.Drawing.Point(32, 0);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(230, 349);
            this.gunaPanel2.TabIndex = 53;
            // 
            // SIGN_UP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(262, 349);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "SIGN_UP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SIGN_UP";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.SIGN_UP_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.SIGN_UP_MouseMove);
            this.gunaPanel1.ResumeLayout(false);
            this.panelInfo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private Guna.UI.WinForms.GunaAdvenceButton btnClose;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaElipse gunaElipse2;
        private System.Windows.Forms.Panel panelInfo;
        private System.Windows.Forms.Label labelMessenge;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox;
        private Guna.UI.WinForms.GunaTextBox TextBoxPassword;
        private Guna.UI.WinForms.GunaTextBox TextBoxUsername;
        private Guna.UI.WinForms.GunaAdvenceButton btnSignUP;
        private Guna.UI.WinForms.GunaTextBox TextBoxSurname;
        private Guna.UI.WinForms.GunaTextBox TextBoxName;
        private Guna.UI.WinForms.GunaLabel Label;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
    }
}