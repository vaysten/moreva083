﻿namespace TheProperty
{
    partial class ReferenceSystem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ReferenceSystem));
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.gunaPanel19 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel21 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel20 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox10 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel22 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox11 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel4 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel5 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox12 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel6 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel7 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox13 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel8 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel9 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPictureBox14 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel10 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel12 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel17 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel19 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel18 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaLabel20 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.flowLayoutPanel1.SuspendLayout();
            this.gunaPanel19.SuspendLayout();
            this.gunaPanel20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).BeginInit();
            this.gunaPanel1.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            this.gunaPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox11)).BeginInit();
            this.gunaPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            this.gunaPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox12)).BeginInit();
            this.gunaPanel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            this.gunaPanel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox13)).BeginInit();
            this.gunaPanel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            this.gunaPanel9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox14)).BeginInit();
            this.gunaPanel10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            this.gunaPanel17.SuspendLayout();
            this.gunaPanel18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel19);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel1);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel3);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel5);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel7);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel9);
            this.flowLayoutPanel1.Controls.Add(this.gunaPanel17);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 40);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(650, 382);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // gunaPanel19
            // 
            this.gunaPanel19.Controls.Add(this.gunaLabel21);
            this.gunaPanel19.Controls.Add(this.gunaPanel20);
            this.gunaPanel19.Location = new System.Drawing.Point(3, 3);
            this.gunaPanel19.Name = "gunaPanel19";
            this.gunaPanel19.Size = new System.Drawing.Size(617, 111);
            this.gunaPanel19.TabIndex = 4;
            // 
            // gunaLabel21
            // 
            this.gunaLabel21.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel21.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel21.Location = new System.Drawing.Point(12, 48);
            this.gunaLabel21.Name = "gunaLabel21";
            this.gunaLabel21.Size = new System.Drawing.Size(592, 53);
            this.gunaLabel21.TabIndex = 3;
            this.gunaLabel21.Text = resources.GetString("gunaLabel21.Text");
            // 
            // gunaPanel20
            // 
            this.gunaPanel20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel20.Controls.Add(this.gunaPictureBox10);
            this.gunaPanel20.Controls.Add(this.gunaLabel22);
            this.gunaPanel20.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel20.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel20.Name = "gunaPanel20";
            this.gunaPanel20.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel20.TabIndex = 1;
            // 
            // gunaPictureBox10
            // 
            this.gunaPictureBox10.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox10.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox10.Image")));
            this.gunaPictureBox10.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox10.Name = "gunaPictureBox10";
            this.gunaPictureBox10.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox10.TabIndex = 2;
            this.gunaPictureBox10.TabStop = false;
            this.gunaPictureBox10.Click += new System.EventHandler(this.gunaPictureBox10_Click);
            // 
            // gunaLabel22
            // 
            this.gunaLabel22.AutoSize = true;
            this.gunaLabel22.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel22.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel22.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel22.Name = "gunaLabel22";
            this.gunaLabel22.Size = new System.Drawing.Size(58, 15);
            this.gunaLabel22.TabIndex = 0;
            this.gunaLabel22.Text = "Введение";
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.Controls.Add(this.gunaLabel3);
            this.gunaPanel1.Controls.Add(this.gunaPanel2);
            this.gunaPanel1.Location = new System.Drawing.Point(3, 120);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(617, 201);
            this.gunaPanel1.TabIndex = 0;
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel3.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel3.Location = new System.Drawing.Point(12, 48);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(592, 146);
            this.gunaLabel3.TabIndex = 3;
            this.gunaLabel3.Text = "Типы недвижимых объектов:\r\n– обособленные водные объекты;\r\n– земельные участки;\r\n" +
    "– недра;\r\n– леса;\r\n– сооружения;\r\n– здания;\r\n– многолетние насаждения;\r\n– объект" +
    "ы незавершенного строительства.";
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel2.Controls.Add(this.gunaPictureBox1);
            this.gunaPanel2.Controls.Add(this.gunaLabel2);
            this.gunaPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel2.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel2.TabIndex = 1;
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox1.Image")));
            this.gunaPictureBox1.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 2;
            this.gunaPictureBox1.TabStop = false;
            this.gunaPictureBox1.Click += new System.EventHandler(this.gunaPictureBox1_Click);
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel2.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel2.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(121, 15);
            this.gunaLabel2.TabIndex = 0;
            this.gunaLabel2.Text = "Типы недвижимости";
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.Controls.Add(this.gunaPictureBox11);
            this.gunaPanel3.Controls.Add(this.gunaLabel5);
            this.gunaPanel3.Controls.Add(this.gunaPanel4);
            this.gunaPanel3.Location = new System.Drawing.Point(3, 327);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(617, 393);
            this.gunaPanel3.TabIndex = 1;
            // 
            // gunaPictureBox11
            // 
            this.gunaPictureBox11.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox11.Image")));
            this.gunaPictureBox11.Location = new System.Drawing.Point(15, 40);
            this.gunaPictureBox11.Name = "gunaPictureBox11";
            this.gunaPictureBox11.Size = new System.Drawing.Size(587, 280);
            this.gunaPictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox11.TabIndex = 4;
            this.gunaPictureBox11.TabStop = false;
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel5.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel5.Location = new System.Drawing.Point(12, 334);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(592, 52);
            this.gunaLabel5.TabIndex = 3;
            this.gunaLabel5.Text = "1. Панель сортировки\r\n2. Список объявлений\r\n3. Панель авторизпции/регистрации\r\n";
            // 
            // gunaPanel4
            // 
            this.gunaPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel4.Controls.Add(this.gunaPictureBox2);
            this.gunaPanel4.Controls.Add(this.gunaLabel6);
            this.gunaPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel4.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel4.Name = "gunaPanel4";
            this.gunaPanel4.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel4.TabIndex = 1;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox2.Image")));
            this.gunaPictureBox2.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 2;
            this.gunaPictureBox2.TabStop = false;
            this.gunaPictureBox2.Click += new System.EventHandler(this.gunaPictureBox2_Click);
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel6.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel6.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(195, 15);
            this.gunaLabel6.TabIndex = 0;
            this.gunaLabel6.Text = "Основной интерфейс программы";
            // 
            // gunaPanel5
            // 
            this.gunaPanel5.Controls.Add(this.gunaLabel4);
            this.gunaPanel5.Controls.Add(this.gunaPictureBox12);
            this.gunaPanel5.Controls.Add(this.gunaPanel6);
            this.gunaPanel5.Location = new System.Drawing.Point(3, 726);
            this.gunaPanel5.Name = "gunaPanel5";
            this.gunaPanel5.Size = new System.Drawing.Size(617, 407);
            this.gunaPanel5.TabIndex = 2;
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel4.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel4.Location = new System.Drawing.Point(12, 350);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(592, 52);
            this.gunaLabel4.TabIndex = 4;
            this.gunaLabel4.Text = "1. Сортировка объявлений\r\n2. Добавление объявления\r\n3. Список ваших опубликованны" +
    "х объявлений";
            // 
            // gunaPictureBox12
            // 
            this.gunaPictureBox12.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox12.Image")));
            this.gunaPictureBox12.Location = new System.Drawing.Point(15, 49);
            this.gunaPictureBox12.Name = "gunaPictureBox12";
            this.gunaPictureBox12.Size = new System.Drawing.Size(589, 295);
            this.gunaPictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox12.TabIndex = 2;
            this.gunaPictureBox12.TabStop = false;
            // 
            // gunaPanel6
            // 
            this.gunaPanel6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel6.Controls.Add(this.gunaPictureBox3);
            this.gunaPanel6.Controls.Add(this.gunaLabel8);
            this.gunaPanel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel6.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel6.Name = "gunaPanel6";
            this.gunaPanel6.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel6.TabIndex = 1;
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox3.Image")));
            this.gunaPictureBox3.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            this.gunaPictureBox3.Click += new System.EventHandler(this.gunaPictureBox3_Click);
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel8.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel8.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(111, 15);
            this.gunaLabel8.TabIndex = 0;
            this.gunaLabel8.Text = "Контекстное меню";
            // 
            // gunaPanel7
            // 
            this.gunaPanel7.Controls.Add(this.gunaPictureBox13);
            this.gunaPanel7.Controls.Add(this.gunaLabel7);
            this.gunaPanel7.Controls.Add(this.gunaPanel8);
            this.gunaPanel7.Location = new System.Drawing.Point(3, 1139);
            this.gunaPanel7.Name = "gunaPanel7";
            this.gunaPanel7.Size = new System.Drawing.Size(617, 428);
            this.gunaPanel7.TabIndex = 3;
            // 
            // gunaPictureBox13
            // 
            this.gunaPictureBox13.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox13.Image")));
            this.gunaPictureBox13.Location = new System.Drawing.Point(15, 44);
            this.gunaPictureBox13.Name = "gunaPictureBox13";
            this.gunaPictureBox13.Size = new System.Drawing.Size(587, 305);
            this.gunaPictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox13.TabIndex = 6;
            this.gunaPictureBox13.TabStop = false;
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel7.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel7.Location = new System.Drawing.Point(10, 355);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(592, 66);
            this.gunaLabel7.TabIndex = 5;
            this.gunaLabel7.Text = "1. Фото недвижимости\r\n2. Размеры недвижимости\r\n3. Имя продавца и телефон\r\n4. Опис" +
    "ание";
            // 
            // gunaPanel8
            // 
            this.gunaPanel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel8.Controls.Add(this.gunaPictureBox4);
            this.gunaPanel8.Controls.Add(this.gunaLabel10);
            this.gunaPanel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel8.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel8.Name = "gunaPanel8";
            this.gunaPanel8.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel8.TabIndex = 1;
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox4.Image")));
            this.gunaPictureBox4.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox4.TabIndex = 2;
            this.gunaPictureBox4.TabStop = false;
            this.gunaPictureBox4.Click += new System.EventHandler(this.gunaPictureBox4_Click);
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel10.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel10.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(140, 15);
            this.gunaLabel10.TabIndex = 0;
            this.gunaLabel10.Text = "Параметры объявления";
            // 
            // gunaPanel9
            // 
            this.gunaPanel9.Controls.Add(this.gunaPictureBox6);
            this.gunaPanel9.Controls.Add(this.gunaLabel9);
            this.gunaPanel9.Controls.Add(this.gunaPictureBox14);
            this.gunaPanel9.Controls.Add(this.gunaLabel11);
            this.gunaPanel9.Controls.Add(this.gunaPanel10);
            this.gunaPanel9.Location = new System.Drawing.Point(3, 1573);
            this.gunaPanel9.Name = "gunaPanel9";
            this.gunaPanel9.Size = new System.Drawing.Size(617, 535);
            this.gunaPanel9.TabIndex = 4;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox6.Image")));
            this.gunaPictureBox6.Location = new System.Drawing.Point(13, 186);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(589, 341);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 9;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel9.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel9.Location = new System.Drawing.Point(12, 158);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(592, 25);
            this.gunaLabel9.TabIndex = 8;
            this.gunaLabel9.Text = "Заполнить все параметры объявления";
            // 
            // gunaPictureBox14
            // 
            this.gunaPictureBox14.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox14.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox14.Image")));
            this.gunaPictureBox14.Location = new System.Drawing.Point(15, 100);
            this.gunaPictureBox14.Name = "gunaPictureBox14";
            this.gunaPictureBox14.Size = new System.Drawing.Size(212, 45);
            this.gunaPictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.gunaPictureBox14.TabIndex = 7;
            this.gunaPictureBox14.TabStop = false;
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel11.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel11.Location = new System.Drawing.Point(12, 48);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(592, 49);
            this.gunaLabel11.TabIndex = 3;
            this.gunaLabel11.Text = "Для добавления объявления необходимо:\r\n1. Зарегистрироваться/ Авторизироваться \r\n" +
    "2. Нажать на кнопку Добавить объявление\r\n ";
            // 
            // gunaPanel10
            // 
            this.gunaPanel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel10.Controls.Add(this.gunaPictureBox5);
            this.gunaPanel10.Controls.Add(this.gunaLabel12);
            this.gunaPanel10.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel10.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel10.Name = "gunaPanel10";
            this.gunaPanel10.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel10.TabIndex = 1;
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox5.Image")));
            this.gunaPictureBox5.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox5.TabIndex = 2;
            this.gunaPictureBox5.TabStop = false;
            this.gunaPictureBox5.Click += new System.EventHandler(this.gunaPictureBox5_Click);
            // 
            // gunaLabel12
            // 
            this.gunaLabel12.AutoSize = true;
            this.gunaLabel12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel12.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel12.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel12.Name = "gunaLabel12";
            this.gunaLabel12.Size = new System.Drawing.Size(143, 15);
            this.gunaLabel12.TabIndex = 0;
            this.gunaLabel12.Text = "Добавление объявления";
            // 
            // gunaPanel17
            // 
            this.gunaPanel17.Controls.Add(this.gunaLabel19);
            this.gunaPanel17.Controls.Add(this.gunaPanel18);
            this.gunaPanel17.Location = new System.Drawing.Point(3, 2114);
            this.gunaPanel17.Name = "gunaPanel17";
            this.gunaPanel17.Size = new System.Drawing.Size(617, 93);
            this.gunaPanel17.TabIndex = 8;
            // 
            // gunaLabel19
            // 
            this.gunaLabel19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel19.ForeColor = System.Drawing.Color.Black;
            this.gunaLabel19.Location = new System.Drawing.Point(12, 48);
            this.gunaLabel19.Name = "gunaLabel19";
            this.gunaLabel19.Size = new System.Drawing.Size(592, 37);
            this.gunaLabel19.TabIndex = 3;
            this.gunaLabel19.Text = "Приложение по автоматизации деятельности АН \"Азбука Недвижимости\"\r\nРазработчик: М" +
    "орева А. А., 083 группа";
            this.gunaLabel19.Click += new System.EventHandler(this.gunaLabel19_Click);
            // 
            // gunaPanel18
            // 
            this.gunaPanel18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel18.Controls.Add(this.gunaPictureBox9);
            this.gunaPanel18.Controls.Add(this.gunaLabel20);
            this.gunaPanel18.Dock = System.Windows.Forms.DockStyle.Top;
            this.gunaPanel18.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel18.Name = "gunaPanel18";
            this.gunaPanel18.Size = new System.Drawing.Size(617, 34);
            this.gunaPanel18.TabIndex = 1;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BackColor = System.Drawing.Color.White;
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox9.Image")));
            this.gunaPictureBox9.Location = new System.Drawing.Point(579, 7);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(23, 20);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 2;
            this.gunaPictureBox9.TabStop = false;
            this.gunaPictureBox9.Click += new System.EventHandler(this.gunaPictureBox9_Click);
            // 
            // gunaLabel20
            // 
            this.gunaLabel20.AutoSize = true;
            this.gunaLabel20.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel20.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel20.Location = new System.Drawing.Point(12, 10);
            this.gunaLabel20.Name = "gunaLabel20";
            this.gunaLabel20.Size = new System.Drawing.Size(82, 15);
            this.gunaLabel20.TabIndex = 0;
            this.gunaLabel20.Text = "О программе";
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI Semibold", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaLabel1.Location = new System.Drawing.Point(233, 7);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(196, 25);
            this.gunaLabel1.TabIndex = 1;
            this.gunaLabel1.Text = "Справочная система";
            // 
            // ReferenceSystem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(662, 422);
            this.Controls.Add(this.gunaLabel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.MaximizeBox = false;
            this.Name = "ReferenceSystem";
            this.Text = "Справочная система";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.gunaPanel19.ResumeLayout(false);
            this.gunaPanel20.ResumeLayout(false);
            this.gunaPanel20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox10)).EndInit();
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            this.gunaPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox11)).EndInit();
            this.gunaPanel4.ResumeLayout(false);
            this.gunaPanel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            this.gunaPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox12)).EndInit();
            this.gunaPanel6.ResumeLayout(false);
            this.gunaPanel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            this.gunaPanel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox13)).EndInit();
            this.gunaPanel8.ResumeLayout(false);
            this.gunaPanel8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            this.gunaPanel9.ResumeLayout(false);
            this.gunaPanel9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox14)).EndInit();
            this.gunaPanel10.ResumeLayout(false);
            this.gunaPanel10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            this.gunaPanel17.ResumeLayout(false);
            this.gunaPanel18.ResumeLayout(false);
            this.gunaPanel18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private Guna.UI.WinForms.GunaPanel gunaPanel19;
        private Guna.UI.WinForms.GunaLabel gunaLabel21;
        private Guna.UI.WinForms.GunaPanel gunaPanel20;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox10;
        private Guna.UI.WinForms.GunaLabel gunaLabel22;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox11;
        private Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaPanel gunaPanel4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaPanel gunaPanel5;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox12;
        private Guna.UI.WinForms.GunaPanel gunaPanel6;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaPanel gunaPanel7;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox13;
        private Guna.UI.WinForms.GunaLabel gunaLabel7;
        private Guna.UI.WinForms.GunaPanel gunaPanel8;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaPanel gunaPanel9;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox14;
        private Guna.UI.WinForms.GunaLabel gunaLabel11;
        private Guna.UI.WinForms.GunaPanel gunaPanel10;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        private Guna.UI.WinForms.GunaLabel gunaLabel12;
        private Guna.UI.WinForms.GunaPanel gunaPanel17;
        private Guna.UI.WinForms.GunaLabel gunaLabel19;
        private Guna.UI.WinForms.GunaPanel gunaPanel18;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        private Guna.UI.WinForms.GunaLabel gunaLabel20;
        private Guna.UI.WinForms.GunaLabel gunaLabel1;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        private Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
    }
}