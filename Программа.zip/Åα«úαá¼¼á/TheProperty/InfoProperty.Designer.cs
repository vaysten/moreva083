﻿namespace TheProperty
{
    partial class InfoProperty
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfoProperty));
            this.gunaPictureBox1 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox5 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.gunaPanel4 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel1 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel7 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.gunaVSeparator1 = new Guna.UI.WinForms.GunaVSeparator();
            this.gunaLabel12 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel13 = new Guna.UI.WinForms.GunaLabel();
            this.gunaSeparator1 = new Guna.UI.WinForms.GunaSeparator();
            this.gunaSeparator2 = new Guna.UI.WinForms.GunaSeparator();
            this.gunaVSeparator2 = new Guna.UI.WinForms.GunaVSeparator();
            this.gunaPictureBox6 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox7 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox8 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPictureBox9 = new Guna.UI.WinForms.GunaPictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).BeginInit();
            this.gunaPanel1.SuspendLayout();
            this.gunaPanel4.SuspendLayout();
            this.gunaPanel3.SuspendLayout();
            this.gunaPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaPictureBox1
            // 
            this.gunaPictureBox1.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox1.Image")));
            this.gunaPictureBox1.Location = new System.Drawing.Point(169, 3);
            this.gunaPictureBox1.Name = "gunaPictureBox1";
            this.gunaPictureBox1.Size = new System.Drawing.Size(600, 400);
            this.gunaPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox1.TabIndex = 0;
            this.gunaPictureBox1.TabStop = false;
            // 
            // gunaPictureBox2
            // 
            this.gunaPictureBox2.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox2.Image")));
            this.gunaPictureBox2.Location = new System.Drawing.Point(42, 14);
            this.gunaPictureBox2.Name = "gunaPictureBox2";
            this.gunaPictureBox2.Size = new System.Drawing.Size(121, 90);
            this.gunaPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox2.TabIndex = 1;
            this.gunaPictureBox2.TabStop = false;
            this.gunaPictureBox2.Click += new System.EventHandler(this.gunaPictureBox2_Click);
            // 
            // gunaPictureBox3
            // 
            this.gunaPictureBox3.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox3.Image")));
            this.gunaPictureBox3.Location = new System.Drawing.Point(42, 206);
            this.gunaPictureBox3.Name = "gunaPictureBox3";
            this.gunaPictureBox3.Size = new System.Drawing.Size(121, 90);
            this.gunaPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox3.TabIndex = 2;
            this.gunaPictureBox3.TabStop = false;
            this.gunaPictureBox3.Click += new System.EventHandler(this.gunaPictureBox3_Click);
            // 
            // gunaPictureBox4
            // 
            this.gunaPictureBox4.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox4.Image")));
            this.gunaPictureBox4.Location = new System.Drawing.Point(42, 110);
            this.gunaPictureBox4.Name = "gunaPictureBox4";
            this.gunaPictureBox4.Size = new System.Drawing.Size(121, 90);
            this.gunaPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox4.TabIndex = 3;
            this.gunaPictureBox4.TabStop = false;
            this.gunaPictureBox4.Click += new System.EventHandler(this.gunaPictureBox4_Click);
            // 
            // gunaPictureBox5
            // 
            this.gunaPictureBox5.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaPictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox5.Image")));
            this.gunaPictureBox5.Location = new System.Drawing.Point(42, 302);
            this.gunaPictureBox5.Name = "gunaPictureBox5";
            this.gunaPictureBox5.Size = new System.Drawing.Size(121, 90);
            this.gunaPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox5.TabIndex = 4;
            this.gunaPictureBox5.TabStop = false;
            this.gunaPictureBox5.Click += new System.EventHandler(this.gunaPictureBox5_Click);
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.Controls.Add(this.gunaPanel4);
            this.gunaPanel1.Controls.Add(this.gunaPanel3);
            this.gunaPanel1.Controls.Add(this.gunaPanel2);
            this.gunaPanel1.Location = new System.Drawing.Point(42, 409);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(727, 44);
            this.gunaPanel1.TabIndex = 6;
            // 
            // gunaPanel4
            // 
            this.gunaPanel4.Controls.Add(this.gunaLabel9);
            this.gunaPanel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel4.Location = new System.Drawing.Point(489, 0);
            this.gunaPanel4.Name = "gunaPanel4";
            this.gunaPanel4.Size = new System.Drawing.Size(238, 44);
            this.gunaPanel4.TabIndex = 2;
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel9.Location = new System.Drawing.Point(6, 3);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(229, 38);
            this.gunaLabel9.TabIndex = 15;
            this.gunaLabel9.Text = "Собственник";
            this.gunaLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.Controls.Add(this.gunaLabel8);
            this.gunaPanel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel3.Location = new System.Drawing.Point(246, 0);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(243, 44);
            this.gunaPanel3.TabIndex = 1;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel8.Location = new System.Drawing.Point(3, 3);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(240, 38);
            this.gunaLabel8.TabIndex = 14;
            this.gunaLabel8.Text = "1-комнатная квартира";
            this.gunaLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaPanel2.Controls.Add(this.gunaLabel10);
            this.gunaPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.gunaPanel2.Location = new System.Drawing.Point(0, 0);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(246, 44);
            this.gunaPanel2.TabIndex = 0;
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel10.ForeColor = System.Drawing.SystemColors.Control;
            this.gunaLabel10.Location = new System.Drawing.Point(4, 3);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(236, 38);
            this.gunaLabel10.TabIndex = 16;
            this.gunaLabel10.Text = "Сутки 70 р. / 30 дней 922 р.";
            this.gunaLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel1
            // 
            this.gunaLabel1.AutoSize = true;
            this.gunaLabel1.Font = new System.Drawing.Font("Segoe UI Semilight", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel1.Location = new System.Drawing.Point(77, 471);
            this.gunaLabel1.Name = "gunaLabel1";
            this.gunaLabel1.Size = new System.Drawing.Size(52, 25);
            this.gunaLabel1.TabIndex = 7;
            this.gunaLabel1.Text = "Этаж";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI Semilight", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel2.Location = new System.Drawing.Point(77, 567);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(156, 50);
            this.gunaLabel2.TabIndex = 8;
            this.gunaLabel2.Text = "Кухня совмещена \r\nс жилой";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI Semilight", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel3.Location = new System.Drawing.Point(77, 535);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(64, 25);
            this.gunaLabel3.TabIndex = 9;
            this.gunaLabel3.Text = "Жилая";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI Semilight", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel4.Location = new System.Drawing.Point(77, 503);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(68, 25);
            this.gunaLabel4.TabIndex = 10;
            this.gunaLabel4.Text = "Общая";
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel5.Location = new System.Drawing.Point(250, 536);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(47, 20);
            this.gunaLabel5.TabIndex = 11;
            this.gunaLabel5.Text = "22 м2";
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel6.Location = new System.Drawing.Point(250, 504);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(47, 20);
            this.gunaLabel6.TabIndex = 12;
            this.gunaLabel6.Text = "30 м2";
            // 
            // gunaLabel7
            // 
            this.gunaLabel7.AutoSize = true;
            this.gunaLabel7.Font = new System.Drawing.Font("Segoe UI Semilight", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel7.Location = new System.Drawing.Point(250, 472);
            this.gunaLabel7.Name = "gunaLabel7";
            this.gunaLabel7.Size = new System.Drawing.Size(37, 20);
            this.gunaLabel7.TabIndex = 13;
            this.gunaLabel7.Text = "7/14";
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.Font = new System.Drawing.Font("Segoe UI Semilight", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel11.Location = new System.Drawing.Point(42, 641);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(727, 204);
            this.gunaLabel11.TabIndex = 14;
            this.gunaLabel11.Text = resources.GetString("gunaLabel11.Text");
            // 
            // gunaVSeparator1
            // 
            this.gunaVSeparator1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator1.Location = new System.Drawing.Point(528, 409);
            this.gunaVSeparator1.Name = "gunaVSeparator1";
            this.gunaVSeparator1.Size = new System.Drawing.Size(10, 208);
            this.gunaVSeparator1.TabIndex = 15;
            // 
            // gunaLabel12
            // 
            this.gunaLabel12.Font = new System.Drawing.Font("Segoe UI Semilight", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel12.Location = new System.Drawing.Point(535, 494);
            this.gunaLabel12.Name = "gunaLabel12";
            this.gunaLabel12.Size = new System.Drawing.Size(234, 19);
            this.gunaLabel12.TabIndex = 16;
            this.gunaLabel12.Text = "+375 29 625-66-99";
            this.gunaLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaLabel13
            // 
            this.gunaLabel13.Font = new System.Drawing.Font("Segoe UI Semilight", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.gunaLabel13.Location = new System.Drawing.Point(535, 471);
            this.gunaLabel13.Name = "gunaLabel13";
            this.gunaLabel13.Size = new System.Drawing.Size(234, 19);
            this.gunaLabel13.TabIndex = 17;
            this.gunaLabel13.Text = "Aлександр";
            this.gunaLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gunaSeparator1
            // 
            this.gunaSeparator1.LineColor = System.Drawing.Color.Silver;
            this.gunaSeparator1.Location = new System.Drawing.Point(288, 404);
            this.gunaSeparator1.Name = "gunaSeparator1";
            this.gunaSeparator1.Size = new System.Drawing.Size(481, 10);
            this.gunaSeparator1.TabIndex = 18;
            // 
            // gunaSeparator2
            // 
            this.gunaSeparator2.LineColor = System.Drawing.Color.Silver;
            this.gunaSeparator2.Location = new System.Drawing.Point(288, 447);
            this.gunaSeparator2.Name = "gunaSeparator2";
            this.gunaSeparator2.Size = new System.Drawing.Size(481, 10);
            this.gunaSeparator2.TabIndex = 19;
            // 
            // gunaVSeparator2
            // 
            this.gunaVSeparator2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.gunaVSeparator2.LineColor = System.Drawing.Color.Silver;
            this.gunaVSeparator2.Location = new System.Drawing.Point(764, 412);
            this.gunaVSeparator2.Name = "gunaVSeparator2";
            this.gunaVSeparator2.Size = new System.Drawing.Size(10, 38);
            this.gunaVSeparator2.TabIndex = 20;
            // 
            // gunaPictureBox6
            // 
            this.gunaPictureBox6.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox6.Image")));
            this.gunaPictureBox6.Location = new System.Drawing.Point(42, 580);
            this.gunaPictureBox6.Name = "gunaPictureBox6";
            this.gunaPictureBox6.Size = new System.Drawing.Size(27, 20);
            this.gunaPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox6.TabIndex = 21;
            this.gunaPictureBox6.TabStop = false;
            // 
            // gunaPictureBox7
            // 
            this.gunaPictureBox7.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox7.Image")));
            this.gunaPictureBox7.Location = new System.Drawing.Point(42, 506);
            this.gunaPictureBox7.Name = "gunaPictureBox7";
            this.gunaPictureBox7.Size = new System.Drawing.Size(27, 20);
            this.gunaPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox7.TabIndex = 22;
            this.gunaPictureBox7.TabStop = false;
            // 
            // gunaPictureBox8
            // 
            this.gunaPictureBox8.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox8.Image")));
            this.gunaPictureBox8.Location = new System.Drawing.Point(42, 538);
            this.gunaPictureBox8.Name = "gunaPictureBox8";
            this.gunaPictureBox8.Size = new System.Drawing.Size(27, 20);
            this.gunaPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox8.TabIndex = 23;
            this.gunaPictureBox8.TabStop = false;
            // 
            // gunaPictureBox9
            // 
            this.gunaPictureBox9.BaseColor = System.Drawing.Color.White;
            this.gunaPictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("gunaPictureBox9.Image")));
            this.gunaPictureBox9.Location = new System.Drawing.Point(42, 474);
            this.gunaPictureBox9.Name = "gunaPictureBox9";
            this.gunaPictureBox9.Size = new System.Drawing.Size(27, 20);
            this.gunaPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.gunaPictureBox9.TabIndex = 24;
            this.gunaPictureBox9.TabStop = false;
            // 
            // InfoProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.Controls.Add(this.gunaPictureBox9);
            this.Controls.Add(this.gunaPictureBox8);
            this.Controls.Add(this.gunaPictureBox7);
            this.Controls.Add(this.gunaPictureBox6);
            this.Controls.Add(this.gunaSeparator1);
            this.Controls.Add(this.gunaVSeparator2);
            this.Controls.Add(this.gunaSeparator2);
            this.Controls.Add(this.gunaLabel13);
            this.Controls.Add(this.gunaLabel12);
            this.Controls.Add(this.gunaVSeparator1);
            this.Controls.Add(this.gunaLabel11);
            this.Controls.Add(this.gunaLabel7);
            this.Controls.Add(this.gunaLabel6);
            this.Controls.Add(this.gunaLabel5);
            this.Controls.Add(this.gunaLabel4);
            this.Controls.Add(this.gunaLabel3);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaLabel1);
            this.Controls.Add(this.gunaPanel1);
            this.Controls.Add(this.gunaPictureBox5);
            this.Controls.Add(this.gunaPictureBox4);
            this.Controls.Add(this.gunaPictureBox3);
            this.Controls.Add(this.gunaPictureBox2);
            this.Controls.Add(this.gunaPictureBox1);
            this.Name = "InfoProperty";
            this.Size = new System.Drawing.Size(769, 518);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox5)).EndInit();
            this.gunaPanel1.ResumeLayout(false);
            this.gunaPanel4.ResumeLayout(false);
            this.gunaPanel3.ResumeLayout(false);
            this.gunaPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gunaPictureBox9)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Guna.UI.WinForms.GunaPanel gunaPanel4;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaVSeparator gunaVSeparator2;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox2;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox3;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox4;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox5;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox1;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox6;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox7;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox8;
        public Guna.UI.WinForms.GunaPictureBox gunaPictureBox9;
        public Guna.UI.WinForms.GunaPanel gunaPanel1;
        public Guna.UI.WinForms.GunaLabel gunaLabel1;
        public Guna.UI.WinForms.GunaLabel gunaLabel2;
        public Guna.UI.WinForms.GunaLabel gunaLabel3;
        public Guna.UI.WinForms.GunaLabel gunaLabel4;
        public Guna.UI.WinForms.GunaLabel gunaLabel5;
        public Guna.UI.WinForms.GunaLabel gunaLabel6;
        public Guna.UI.WinForms.GunaLabel gunaLabel7;
        public Guna.UI.WinForms.GunaLabel gunaLabel11;
        public Guna.UI.WinForms.GunaVSeparator gunaVSeparator1;
        public Guna.UI.WinForms.GunaLabel gunaLabel12;
        public Guna.UI.WinForms.GunaLabel gunaLabel13;
        public Guna.UI.WinForms.GunaSeparator gunaSeparator1;
        public Guna.UI.WinForms.GunaSeparator gunaSeparator2;
        public Guna.UI.WinForms.GunaLabel gunaLabel9;
        public Guna.UI.WinForms.GunaLabel gunaLabel8;
        public Guna.UI.WinForms.GunaLabel gunaLabel10;
    }
}
