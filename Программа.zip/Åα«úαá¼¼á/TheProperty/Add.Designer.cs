﻿namespace TheProperty
{
    partial class Add
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Add));
            this.gunaElipse1 = new Guna.UI.WinForms.GunaElipse(this.components);
            this.TextBoxPrice = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel8 = new Guna.UI.WinForms.GunaLabel();
            this.TextBox1 = new Guna.UI.WinForms.GunaTextBox();
            this.TextBox2 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel12 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel9 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel11 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel2 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel3 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel4 = new Guna.UI.WinForms.GunaLabel();
            this.TextBoxAdress = new Guna.UI.WinForms.GunaTextBox();
            this.TextBoxNameSell = new Guna.UI.WinForms.GunaTextBox();
            this.gunaPanel1 = new Guna.UI.WinForms.GunaPanel();
            this.PictureBox = new Guna.UI.WinForms.GunaPictureBox();
            this.btnCancel = new Guna.UI.WinForms.GunaAdvenceButton();
            this.btnAdd = new Guna.UI.WinForms.GunaAdvenceButton();
            this.TextBoxDiscription = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel6 = new Guna.UI.WinForms.GunaLabel();
            this.btnBrowse = new Guna.UI.WinForms.GunaAdvenceButton();
            this.TextBoxPhone = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel14 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel15 = new Guna.UI.WinForms.GunaLabel();
            this.TextBoxPrice30 = new Guna.UI.WinForms.GunaTextBox();
            this.gunaLabel17 = new Guna.UI.WinForms.GunaLabel();
            this.gunaLabel18 = new Guna.UI.WinForms.GunaLabel();
            this.ComboBox1 = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel19 = new Guna.UI.WinForms.GunaLabel();
            this.ComboBoxTio = new Guna.UI.WinForms.GunaComboBox();
            this.ComboBoxSeller = new Guna.UI.WinForms.GunaComboBox();
            this.gunaLabel5 = new Guna.UI.WinForms.GunaLabel();
            this.gunaNumeric1 = new Guna.UI.WinForms.GunaNumeric();
            this.gunaNumeric2 = new Guna.UI.WinForms.GunaNumeric();
            this.gunaLabel10 = new Guna.UI.WinForms.GunaLabel();
            this.gunaNumeric3 = new Guna.UI.WinForms.GunaNumeric();
            this.gunaPanel2 = new Guna.UI.WinForms.GunaPanel();
            this.gunaAdvenceButton3 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaPanel5 = new Guna.UI.WinForms.GunaPanel();
            this.PictureBox4 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaAdvenceButton2 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaPanel4 = new Guna.UI.WinForms.GunaPanel();
            this.PictureBox3 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaAdvenceButton1 = new Guna.UI.WinForms.GunaAdvenceButton();
            this.gunaPanel3 = new Guna.UI.WinForms.GunaPanel();
            this.PictureBox2 = new Guna.UI.WinForms.GunaPictureBox();
            this.gunaPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox)).BeginInit();
            this.gunaPanel2.SuspendLayout();
            this.gunaPanel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            this.gunaPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            this.gunaPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // gunaElipse1
            // 
            this.gunaElipse1.Radius = 15;
            this.gunaElipse1.TargetControl = this;
            // 
            // TextBoxPrice
            // 
            this.TextBoxPrice.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxPrice.BaseColor = System.Drawing.Color.White;
            this.TextBoxPrice.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxPrice.BorderSize = 1;
            this.TextBoxPrice.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPrice.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxPrice.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxPrice.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxPrice.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxPrice.Location = new System.Drawing.Point(102, 478);
            this.TextBoxPrice.Name = "TextBoxPrice";
            this.TextBoxPrice.PasswordChar = '\0';
            this.TextBoxPrice.Radius = 10;
            this.TextBoxPrice.Size = new System.Drawing.Size(98, 26);
            this.TextBoxPrice.TabIndex = 45;
            // 
            // gunaLabel8
            // 
            this.gunaLabel8.AutoSize = true;
            this.gunaLabel8.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel8.Location = new System.Drawing.Point(15, 483);
            this.gunaLabel8.Name = "gunaLabel8";
            this.gunaLabel8.Size = new System.Drawing.Size(85, 15);
            this.gunaLabel8.TabIndex = 46;
            this.gunaLabel8.Text = "Цена за сутки ";
            // 
            // TextBox1
            // 
            this.TextBox1.BackColor = System.Drawing.Color.Transparent;
            this.TextBox1.BaseColor = System.Drawing.Color.White;
            this.TextBox1.BorderColor = System.Drawing.Color.Silver;
            this.TextBox1.BorderSize = 1;
            this.TextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBox1.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBox1.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBox1.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBox1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBox1.Location = new System.Drawing.Point(550, 87);
            this.TextBox1.Name = "TextBox1";
            this.TextBox1.PasswordChar = '\0';
            this.TextBox1.Radius = 10;
            this.TextBox1.Size = new System.Drawing.Size(164, 30);
            this.TextBox1.TabIndex = 13;
            // 
            // TextBox2
            // 
            this.TextBox2.BackColor = System.Drawing.Color.Transparent;
            this.TextBox2.BaseColor = System.Drawing.Color.White;
            this.TextBox2.BorderColor = System.Drawing.Color.Silver;
            this.TextBox2.BorderSize = 1;
            this.TextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBox2.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBox2.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBox2.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBox2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBox2.Location = new System.Drawing.Point(540, 124);
            this.TextBox2.Name = "TextBox2";
            this.TextBox2.PasswordChar = '\0';
            this.TextBox2.Radius = 10;
            this.TextBox2.Size = new System.Drawing.Size(173, 30);
            this.TextBox2.TabIndex = 15;
            // 
            // gunaLabel12
            // 
            this.gunaLabel12.AutoSize = true;
            this.gunaLabel12.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel12.Location = new System.Drawing.Point(443, 133);
            this.gunaLabel12.Name = "gunaLabel12";
            this.gunaLabel12.Size = new System.Drawing.Size(94, 15);
            this.gunaLabel12.TabIndex = 33;
            this.gunaLabel12.Text = "Площадь кухни";
            // 
            // gunaLabel9
            // 
            this.gunaLabel9.AutoSize = true;
            this.gunaLabel9.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel9.Location = new System.Drawing.Point(443, 95);
            this.gunaLabel9.Name = "gunaLabel9";
            this.gunaLabel9.Size = new System.Drawing.Size(99, 15);
            this.gunaLabel9.TabIndex = 29;
            this.gunaLabel9.Text = "Общая площадь";
            this.gunaLabel9.Click += new System.EventHandler(this.gunaLabel9_Click);
            // 
            // gunaLabel11
            // 
            this.gunaLabel11.AutoSize = true;
            this.gunaLabel11.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel11.Location = new System.Drawing.Point(162, 138);
            this.gunaLabel11.Name = "gunaLabel11";
            this.gunaLabel11.Size = new System.Drawing.Size(112, 15);
            this.gunaLabel11.TabIndex = 26;
            this.gunaLabel11.Text = "Тип недвижимости";
            // 
            // gunaLabel2
            // 
            this.gunaLabel2.AutoSize = true;
            this.gunaLabel2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel2.Location = new System.Drawing.Point(162, 32);
            this.gunaLabel2.Name = "gunaLabel2";
            this.gunaLabel2.Size = new System.Drawing.Size(40, 15);
            this.gunaLabel2.TabIndex = 3;
            this.gunaLabel2.Text = "Адрес";
            // 
            // gunaLabel3
            // 
            this.gunaLabel3.AutoSize = true;
            this.gunaLabel3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel3.Location = new System.Drawing.Point(162, 70);
            this.gunaLabel3.Name = "gunaLabel3";
            this.gunaLabel3.Size = new System.Drawing.Size(34, 15);
            this.gunaLabel3.TabIndex = 4;
            this.gunaLabel3.Text = "Этаж";
            // 
            // gunaLabel4
            // 
            this.gunaLabel4.AutoSize = true;
            this.gunaLabel4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel4.Location = new System.Drawing.Point(443, 61);
            this.gunaLabel4.Name = "gunaLabel4";
            this.gunaLabel4.Size = new System.Drawing.Size(91, 15);
            this.gunaLabel4.TabIndex = 5;
            this.gunaLabel4.Text = "Имя владельца";
            // 
            // TextBoxAdress
            // 
            this.TextBoxAdress.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxAdress.BaseColor = System.Drawing.Color.White;
            this.TextBoxAdress.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxAdress.BorderSize = 1;
            this.TextBoxAdress.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxAdress.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxAdress.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxAdress.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxAdress.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxAdress.Location = new System.Drawing.Point(208, 25);
            this.TextBoxAdress.Name = "TextBoxAdress";
            this.TextBoxAdress.PasswordChar = '\0';
            this.TextBoxAdress.Radius = 10;
            this.TextBoxAdress.Size = new System.Drawing.Size(222, 30);
            this.TextBoxAdress.TabIndex = 9;
            // 
            // TextBoxNameSell
            // 
            this.TextBoxNameSell.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxNameSell.BaseColor = System.Drawing.Color.White;
            this.TextBoxNameSell.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxNameSell.BorderSize = 1;
            this.TextBoxNameSell.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxNameSell.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxNameSell.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxNameSell.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxNameSell.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxNameSell.Location = new System.Drawing.Point(540, 55);
            this.TextBoxNameSell.Name = "TextBoxNameSell";
            this.TextBoxNameSell.PasswordChar = '\0';
            this.TextBoxNameSell.Radius = 10;
            this.TextBoxNameSell.Size = new System.Drawing.Size(173, 26);
            this.TextBoxNameSell.TabIndex = 16;
            // 
            // gunaPanel1
            // 
            this.gunaPanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gunaPanel1.Controls.Add(this.PictureBox);
            this.gunaPanel1.Location = new System.Drawing.Point(3, 1);
            this.gunaPanel1.Name = "gunaPanel1";
            this.gunaPanel1.Size = new System.Drawing.Size(133, 164);
            this.gunaPanel1.TabIndex = 43;
            // 
            // PictureBox
            // 
            this.PictureBox.BaseColor = System.Drawing.Color.White;
            this.PictureBox.Location = new System.Drawing.Point(0, 0);
            this.PictureBox.Name = "PictureBox";
            this.PictureBox.Size = new System.Drawing.Size(133, 164);
            this.PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox.TabIndex = 0;
            this.PictureBox.TabStop = false;
            // 
            // btnCancel
            // 
            this.btnCancel.AnimationHoverSpeed = 0.07F;
            this.btnCancel.AnimationSpeed = 0.03F;
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BaseColor = System.Drawing.Color.Black;
            this.btnCancel.BorderColor = System.Drawing.Color.Black;
            this.btnCancel.CheckedBaseColor = System.Drawing.Color.Gray;
            this.btnCancel.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnCancel.CheckedForeColor = System.Drawing.Color.White;
            this.btnCancel.CheckedImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.CheckedImage")));
            this.btnCancel.CheckedLineColor = System.Drawing.Color.DimGray;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnCancel.FocusedColor = System.Drawing.Color.Empty;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageSize = new System.Drawing.Size(20, 20);
            this.btnCancel.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.Location = new System.Drawing.Point(462, 475);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.btnCancel.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnCancel.OnHoverForeColor = System.Drawing.Color.White;
            this.btnCancel.OnHoverImage = null;
            this.btnCancel.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnCancel.OnPressedColor = System.Drawing.Color.Black;
            this.btnCancel.Radius = 10;
            this.btnCancel.Size = new System.Drawing.Size(107, 31);
            this.btnCancel.TabIndex = 42;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.AnimationHoverSpeed = 0.07F;
            this.btnAdd.AnimationSpeed = 0.03F;
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.BaseColor = System.Drawing.Color.Black;
            this.btnAdd.BorderColor = System.Drawing.Color.Black;
            this.btnAdd.CheckedBaseColor = System.Drawing.Color.Gray;
            this.btnAdd.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnAdd.CheckedForeColor = System.Drawing.Color.White;
            this.btnAdd.CheckedImage = ((System.Drawing.Image)(resources.GetObject("btnAdd.CheckedImage")));
            this.btnAdd.CheckedLineColor = System.Drawing.Color.DimGray;
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnAdd.FocusedColor = System.Drawing.Color.Empty;
            this.btnAdd.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.ImageSize = new System.Drawing.Size(20, 20);
            this.btnAdd.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAdd.Location = new System.Drawing.Point(575, 475);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.btnAdd.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnAdd.OnHoverForeColor = System.Drawing.Color.White;
            this.btnAdd.OnHoverImage = null;
            this.btnAdd.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnAdd.OnPressedColor = System.Drawing.Color.Black;
            this.btnAdd.Radius = 10;
            this.btnAdd.Size = new System.Drawing.Size(140, 31);
            this.btnAdd.TabIndex = 41;
            this.btnAdd.Text = "Опубликовать";
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // TextBoxDiscription
            // 
            this.TextBoxDiscription.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxDiscription.BaseColor = System.Drawing.Color.White;
            this.TextBoxDiscription.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxDiscription.BorderSize = 1;
            this.TextBoxDiscription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxDiscription.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxDiscription.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxDiscription.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxDiscription.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxDiscription.Location = new System.Drawing.Point(161, 225);
            this.TextBoxDiscription.MultiLine = true;
            this.TextBoxDiscription.Name = "TextBoxDiscription";
            this.TextBoxDiscription.PasswordChar = '\0';
            this.TextBoxDiscription.Radius = 10;
            this.TextBoxDiscription.Size = new System.Drawing.Size(555, 242);
            this.TextBoxDiscription.TabIndex = 40;
            // 
            // gunaLabel6
            // 
            this.gunaLabel6.AutoSize = true;
            this.gunaLabel6.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel6.Location = new System.Drawing.Point(162, 207);
            this.gunaLabel6.Name = "gunaLabel6";
            this.gunaLabel6.Size = new System.Drawing.Size(55, 15);
            this.gunaLabel6.TabIndex = 39;
            this.gunaLabel6.Text = "Описаие";
            // 
            // btnBrowse
            // 
            this.btnBrowse.AnimationHoverSpeed = 0.07F;
            this.btnBrowse.AnimationSpeed = 0.03F;
            this.btnBrowse.BackColor = System.Drawing.Color.Transparent;
            this.btnBrowse.BaseColor = System.Drawing.Color.Black;
            this.btnBrowse.BorderColor = System.Drawing.Color.Black;
            this.btnBrowse.CheckedBaseColor = System.Drawing.Color.Gray;
            this.btnBrowse.CheckedBorderColor = System.Drawing.Color.Black;
            this.btnBrowse.CheckedForeColor = System.Drawing.Color.White;
            this.btnBrowse.CheckedImage = ((System.Drawing.Image)(resources.GetObject("btnBrowse.CheckedImage")));
            this.btnBrowse.CheckedLineColor = System.Drawing.Color.DimGray;
            this.btnBrowse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBrowse.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBrowse.FocusedColor = System.Drawing.Color.Empty;
            this.btnBrowse.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBrowse.ForeColor = System.Drawing.Color.White;
            this.btnBrowse.Image = ((System.Drawing.Image)(resources.GetObject("btnBrowse.Image")));
            this.btnBrowse.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnBrowse.ImageSize = new System.Drawing.Size(20, 20);
            this.btnBrowse.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBrowse.Location = new System.Drawing.Point(12, 172);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.btnBrowse.OnHoverBorderColor = System.Drawing.Color.Black;
            this.btnBrowse.OnHoverForeColor = System.Drawing.Color.White;
            this.btnBrowse.OnHoverImage = null;
            this.btnBrowse.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnBrowse.OnPressedColor = System.Drawing.Color.Black;
            this.btnBrowse.Radius = 10;
            this.btnBrowse.Size = new System.Drawing.Size(114, 31);
            this.btnBrowse.TabIndex = 38;
            this.btnBrowse.Text = "Browse 1";
            this.btnBrowse.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // TextBoxPhone
            // 
            this.TextBoxPhone.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxPhone.BaseColor = System.Drawing.Color.White;
            this.TextBoxPhone.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxPhone.BorderSize = 1;
            this.TextBoxPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPhone.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxPhone.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxPhone.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxPhone.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxPhone.Location = new System.Drawing.Point(508, 19);
            this.TextBoxPhone.Name = "TextBoxPhone";
            this.TextBoxPhone.PasswordChar = '\0';
            this.TextBoxPhone.Radius = 10;
            this.TextBoxPhone.Size = new System.Drawing.Size(205, 30);
            this.TextBoxPhone.TabIndex = 48;
            // 
            // gunaLabel14
            // 
            this.gunaLabel14.AutoSize = true;
            this.gunaLabel14.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel14.Location = new System.Drawing.Point(443, 26);
            this.gunaLabel14.Name = "gunaLabel14";
            this.gunaLabel14.Size = new System.Drawing.Size(55, 15);
            this.gunaLabel14.TabIndex = 47;
            this.gunaLabel14.Text = "Телефон";
            // 
            // gunaLabel15
            // 
            this.gunaLabel15.AutoSize = true;
            this.gunaLabel15.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel15.Location = new System.Drawing.Point(225, 483);
            this.gunaLabel15.Name = "gunaLabel15";
            this.gunaLabel15.Size = new System.Drawing.Size(93, 15);
            this.gunaLabel15.TabIndex = 50;
            this.gunaLabel15.Text = "Цена за 30 дней";
            this.gunaLabel15.Click += new System.EventHandler(this.gunaLabel15_Click);
            // 
            // TextBoxPrice30
            // 
            this.TextBoxPrice30.BackColor = System.Drawing.Color.Transparent;
            this.TextBoxPrice30.BaseColor = System.Drawing.Color.White;
            this.TextBoxPrice30.BorderColor = System.Drawing.Color.Silver;
            this.TextBoxPrice30.BorderSize = 1;
            this.TextBoxPrice30.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TextBoxPrice30.FocusedBaseColor = System.Drawing.Color.White;
            this.TextBoxPrice30.FocusedBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.TextBoxPrice30.FocusedForeColor = System.Drawing.SystemColors.ControlText;
            this.TextBoxPrice30.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.TextBoxPrice30.Location = new System.Drawing.Point(329, 478);
            this.TextBoxPrice30.Name = "TextBoxPrice30";
            this.TextBoxPrice30.PasswordChar = '\0';
            this.TextBoxPrice30.Radius = 10;
            this.TextBoxPrice30.Size = new System.Drawing.Size(101, 26);
            this.TextBoxPrice30.TabIndex = 51;
            // 
            // gunaLabel17
            // 
            this.gunaLabel17.AutoSize = true;
            this.gunaLabel17.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel17.Location = new System.Drawing.Point(443, 165);
            this.gunaLabel17.Name = "gunaLabel17";
            this.gunaLabel17.Size = new System.Drawing.Size(48, 15);
            this.gunaLabel17.TabIndex = 55;
            this.gunaLabel17.Text = "Ремонт";
            // 
            // gunaLabel18
            // 
            this.gunaLabel18.AutoSize = true;
            this.gunaLabel18.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel18.Location = new System.Drawing.Point(162, 170);
            this.gunaLabel18.Name = "gunaLabel18";
            this.gunaLabel18.Size = new System.Drawing.Size(62, 15);
            this.gunaLabel18.TabIndex = 57;
            this.gunaLabel18.Text = "Продовец";
            // 
            // ComboBox1
            // 
            this.ComboBox1.BackColor = System.Drawing.Color.Transparent;
            this.ComboBox1.BaseColor = System.Drawing.Color.White;
            this.ComboBox1.BorderColor = System.Drawing.Color.Silver;
            this.ComboBox1.BorderSize = 1;
            this.ComboBox1.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBox1.FocusedColor = System.Drawing.Color.Empty;
            this.ComboBox1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.ComboBox1.ForeColor = System.Drawing.Color.Black;
            this.ComboBox1.FormattingEnabled = true;
            this.ComboBox1.Items.AddRange(new object[] {
            "Косметический",
            "Капитальный",
            "Реконструированный",
            "Авторский",
            "Евроремонт"});
            this.ComboBox1.Location = new System.Drawing.Point(497, 160);
            this.ComboBox1.Name = "ComboBox1";
            this.ComboBox1.OnHoverItemBaseColor = System.Drawing.Color.Black;
            this.ComboBox1.OnHoverItemForeColor = System.Drawing.Color.White;
            this.ComboBox1.Radius = 10;
            this.ComboBox1.Size = new System.Drawing.Size(217, 26);
            this.ComboBox1.TabIndex = 56;
            // 
            // gunaLabel19
            // 
            this.gunaLabel19.AutoSize = true;
            this.gunaLabel19.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel19.Location = new System.Drawing.Point(162, 105);
            this.gunaLabel19.Name = "gunaLabel19";
            this.gunaLabel19.Size = new System.Drawing.Size(89, 15);
            this.gunaLabel19.TabIndex = 59;
            this.gunaLabel19.Text = "Кол-во комнат";
            // 
            // ComboBoxTio
            // 
            this.ComboBoxTio.BackColor = System.Drawing.Color.Transparent;
            this.ComboBoxTio.BaseColor = System.Drawing.Color.White;
            this.ComboBoxTio.BorderColor = System.Drawing.Color.Silver;
            this.ComboBoxTio.BorderSize = 1;
            this.ComboBoxTio.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ComboBoxTio.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxTio.FocusedColor = System.Drawing.Color.Empty;
            this.ComboBoxTio.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.ComboBoxTio.ForeColor = System.Drawing.Color.Black;
            this.ComboBoxTio.FormattingEnabled = true;
            this.ComboBoxTio.Items.AddRange(new object[] {
            "Квартира",
            "Дом",
            "Офис"});
            this.ComboBoxTio.Location = new System.Drawing.Point(280, 133);
            this.ComboBoxTio.Name = "ComboBoxTio";
            this.ComboBoxTio.OnHoverItemBaseColor = System.Drawing.Color.Black;
            this.ComboBoxTio.OnHoverItemForeColor = System.Drawing.Color.White;
            this.ComboBoxTio.Radius = 10;
            this.ComboBoxTio.Size = new System.Drawing.Size(150, 26);
            this.ComboBoxTio.TabIndex = 61;
            // 
            // ComboBoxSeller
            // 
            this.ComboBoxSeller.BackColor = System.Drawing.Color.Transparent;
            this.ComboBoxSeller.BaseColor = System.Drawing.Color.White;
            this.ComboBoxSeller.BorderColor = System.Drawing.Color.Silver;
            this.ComboBoxSeller.BorderSize = 1;
            this.ComboBoxSeller.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.ComboBoxSeller.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ComboBoxSeller.FocusedColor = System.Drawing.Color.Empty;
            this.ComboBoxSeller.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.ComboBoxSeller.ForeColor = System.Drawing.Color.Black;
            this.ComboBoxSeller.FormattingEnabled = true;
            this.ComboBoxSeller.Items.AddRange(new object[] {
            "Агенство",
            "Собственник"});
            this.ComboBoxSeller.Location = new System.Drawing.Point(230, 165);
            this.ComboBoxSeller.Name = "ComboBoxSeller";
            this.ComboBoxSeller.OnHoverItemBaseColor = System.Drawing.Color.Black;
            this.ComboBoxSeller.OnHoverItemForeColor = System.Drawing.Color.White;
            this.ComboBoxSeller.Radius = 10;
            this.ComboBoxSeller.Size = new System.Drawing.Size(200, 26);
            this.ComboBoxSeller.TabIndex = 62;
            // 
            // gunaLabel5
            // 
            this.gunaLabel5.AutoSize = true;
            this.gunaLabel5.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel5.Location = new System.Drawing.Point(618, 300);
            this.gunaLabel5.Name = "gunaLabel5";
            this.gunaLabel5.Size = new System.Drawing.Size(62, 15);
            this.gunaLabel5.TabIndex = 63;
            this.gunaLabel5.Text = "NameUser";
            this.gunaLabel5.UseMnemonic = false;
            // 
            // gunaNumeric1
            // 
            this.gunaNumeric1.BackColor = System.Drawing.Color.Transparent;
            this.gunaNumeric1.BaseColor = System.Drawing.Color.White;
            this.gunaNumeric1.BorderColor = System.Drawing.Color.Silver;
            this.gunaNumeric1.ButtonColor = System.Drawing.Color.Black;
            this.gunaNumeric1.ButtonForeColor = System.Drawing.Color.White;
            this.gunaNumeric1.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.gunaNumeric1.ForeColor = System.Drawing.Color.Black;
            this.gunaNumeric1.Location = new System.Drawing.Point(202, 61);
            this.gunaNumeric1.Maximum = ((long)(9999999));
            this.gunaNumeric1.Minimum = ((long)(0));
            this.gunaNumeric1.Name = "gunaNumeric1";
            this.gunaNumeric1.Radius = 10;
            this.gunaNumeric1.Size = new System.Drawing.Size(101, 30);
            this.gunaNumeric1.TabIndex = 64;
            this.gunaNumeric1.Text = "gunaNumeric1";
            this.gunaNumeric1.Value = ((long)(0));
            // 
            // gunaNumeric2
            // 
            this.gunaNumeric2.BackColor = System.Drawing.Color.Transparent;
            this.gunaNumeric2.BaseColor = System.Drawing.Color.White;
            this.gunaNumeric2.BorderColor = System.Drawing.Color.Silver;
            this.gunaNumeric2.ButtonColor = System.Drawing.Color.Black;
            this.gunaNumeric2.ButtonForeColor = System.Drawing.Color.White;
            this.gunaNumeric2.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.gunaNumeric2.ForeColor = System.Drawing.Color.Black;
            this.gunaNumeric2.Location = new System.Drawing.Point(257, 97);
            this.gunaNumeric2.Maximum = ((long)(9999999));
            this.gunaNumeric2.Minimum = ((long)(0));
            this.gunaNumeric2.Name = "gunaNumeric2";
            this.gunaNumeric2.Radius = 10;
            this.gunaNumeric2.Size = new System.Drawing.Size(173, 30);
            this.gunaNumeric2.TabIndex = 65;
            this.gunaNumeric2.Text = "gunaNumeric2";
            this.gunaNumeric2.Value = ((long)(0));
            // 
            // gunaLabel10
            // 
            this.gunaLabel10.AutoSize = true;
            this.gunaLabel10.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaLabel10.Location = new System.Drawing.Point(309, 70);
            this.gunaLabel10.Name = "gunaLabel10";
            this.gunaLabel10.Size = new System.Drawing.Size(12, 15);
            this.gunaLabel10.TabIndex = 66;
            this.gunaLabel10.Text = "/";
            // 
            // gunaNumeric3
            // 
            this.gunaNumeric3.BackColor = System.Drawing.Color.Transparent;
            this.gunaNumeric3.BaseColor = System.Drawing.Color.White;
            this.gunaNumeric3.BorderColor = System.Drawing.Color.Silver;
            this.gunaNumeric3.ButtonColor = System.Drawing.Color.Black;
            this.gunaNumeric3.ButtonForeColor = System.Drawing.Color.White;
            this.gunaNumeric3.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.gunaNumeric3.ForeColor = System.Drawing.Color.Black;
            this.gunaNumeric3.Location = new System.Drawing.Point(327, 61);
            this.gunaNumeric3.Maximum = ((long)(9999999));
            this.gunaNumeric3.Minimum = ((long)(0));
            this.gunaNumeric3.Name = "gunaNumeric3";
            this.gunaNumeric3.Radius = 10;
            this.gunaNumeric3.Size = new System.Drawing.Size(103, 30);
            this.gunaNumeric3.TabIndex = 67;
            this.gunaNumeric3.Text = "gunaNumeric3";
            this.gunaNumeric3.Value = ((long)(0));
            // 
            // gunaPanel2
            // 
            this.gunaPanel2.AutoScroll = true;
            this.gunaPanel2.Controls.Add(this.gunaAdvenceButton3);
            this.gunaPanel2.Controls.Add(this.gunaPanel5);
            this.gunaPanel2.Controls.Add(this.gunaAdvenceButton2);
            this.gunaPanel2.Controls.Add(this.gunaPanel4);
            this.gunaPanel2.Controls.Add(this.gunaAdvenceButton1);
            this.gunaPanel2.Controls.Add(this.gunaPanel3);
            this.gunaPanel2.Controls.Add(this.btnBrowse);
            this.gunaPanel2.Controls.Add(this.gunaPanel1);
            this.gunaPanel2.Location = new System.Drawing.Point(14, 19);
            this.gunaPanel2.Name = "gunaPanel2";
            this.gunaPanel2.Size = new System.Drawing.Size(142, 448);
            this.gunaPanel2.TabIndex = 68;
            // 
            // gunaAdvenceButton3
            // 
            this.gunaAdvenceButton3.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton3.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton3.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton3.BaseColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton3.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton3.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton3.CheckedImage")));
            this.gunaAdvenceButton3.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaAdvenceButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton3.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton3.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton3.Image = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton3.Image")));
            this.gunaAdvenceButton3.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton3.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton3.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton3.Location = new System.Drawing.Point(152, 400);
            this.gunaAdvenceButton3.Name = "gunaAdvenceButton3";
            this.gunaAdvenceButton3.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton3.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton3.OnHoverImage = null;
            this.gunaAdvenceButton3.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton3.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton3.Radius = 10;
            this.gunaAdvenceButton3.Size = new System.Drawing.Size(114, 31);
            this.gunaAdvenceButton3.TabIndex = 48;
            this.gunaAdvenceButton3.Text = "Browse 4";
            this.gunaAdvenceButton3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton3.Click += new System.EventHandler(this.gunaAdvenceButton3_Click);
            // 
            // gunaPanel5
            // 
            this.gunaPanel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gunaPanel5.Controls.Add(this.PictureBox4);
            this.gunaPanel5.Location = new System.Drawing.Point(144, 230);
            this.gunaPanel5.Name = "gunaPanel5";
            this.gunaPanel5.Size = new System.Drawing.Size(133, 164);
            this.gunaPanel5.TabIndex = 49;
            // 
            // PictureBox4
            // 
            this.PictureBox4.BaseColor = System.Drawing.Color.White;
            this.PictureBox4.Location = new System.Drawing.Point(0, 0);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(133, 164);
            this.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox4.TabIndex = 0;
            this.PictureBox4.TabStop = false;
            // 
            // gunaAdvenceButton2
            // 
            this.gunaAdvenceButton2.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton2.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton2.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton2.BaseColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton2.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton2.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton2.CheckedImage")));
            this.gunaAdvenceButton2.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaAdvenceButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton2.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton2.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton2.Image = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton2.Image")));
            this.gunaAdvenceButton2.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton2.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton2.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton2.Location = new System.Drawing.Point(152, 172);
            this.gunaAdvenceButton2.Name = "gunaAdvenceButton2";
            this.gunaAdvenceButton2.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton2.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton2.OnHoverImage = null;
            this.gunaAdvenceButton2.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton2.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton2.Radius = 10;
            this.gunaAdvenceButton2.Size = new System.Drawing.Size(114, 31);
            this.gunaAdvenceButton2.TabIndex = 46;
            this.gunaAdvenceButton2.Text = "Browse 3";
            this.gunaAdvenceButton2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton2.Click += new System.EventHandler(this.gunaAdvenceButton2_Click);
            // 
            // gunaPanel4
            // 
            this.gunaPanel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gunaPanel4.Controls.Add(this.PictureBox3);
            this.gunaPanel4.Location = new System.Drawing.Point(144, 2);
            this.gunaPanel4.Name = "gunaPanel4";
            this.gunaPanel4.Size = new System.Drawing.Size(133, 164);
            this.gunaPanel4.TabIndex = 47;
            // 
            // PictureBox3
            // 
            this.PictureBox3.BaseColor = System.Drawing.Color.White;
            this.PictureBox3.Location = new System.Drawing.Point(0, 0);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(133, 164);
            this.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox3.TabIndex = 0;
            this.PictureBox3.TabStop = false;
            // 
            // gunaAdvenceButton1
            // 
            this.gunaAdvenceButton1.AnimationHoverSpeed = 0.07F;
            this.gunaAdvenceButton1.AnimationSpeed = 0.03F;
            this.gunaAdvenceButton1.BackColor = System.Drawing.Color.Transparent;
            this.gunaAdvenceButton1.BaseColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.BorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.CheckedBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton1.CheckedBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.CheckedForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton1.CheckedImage = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton1.CheckedImage")));
            this.gunaAdvenceButton1.CheckedLineColor = System.Drawing.Color.DimGray;
            this.gunaAdvenceButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.gunaAdvenceButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.gunaAdvenceButton1.FocusedColor = System.Drawing.Color.Empty;
            this.gunaAdvenceButton1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.gunaAdvenceButton1.ForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton1.Image = ((System.Drawing.Image)(resources.GetObject("gunaAdvenceButton1.Image")));
            this.gunaAdvenceButton1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton1.ImageSize = new System.Drawing.Size(20, 20);
            this.gunaAdvenceButton1.LineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton1.Location = new System.Drawing.Point(9, 400);
            this.gunaAdvenceButton1.Name = "gunaAdvenceButton1";
            this.gunaAdvenceButton1.OnHoverBaseColor = System.Drawing.Color.Gray;
            this.gunaAdvenceButton1.OnHoverBorderColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.OnHoverForeColor = System.Drawing.Color.White;
            this.gunaAdvenceButton1.OnHoverImage = null;
            this.gunaAdvenceButton1.OnHoverLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.gunaAdvenceButton1.OnPressedColor = System.Drawing.Color.Black;
            this.gunaAdvenceButton1.Radius = 10;
            this.gunaAdvenceButton1.Size = new System.Drawing.Size(114, 31);
            this.gunaAdvenceButton1.TabIndex = 44;
            this.gunaAdvenceButton1.Text = "Browse 2";
            this.gunaAdvenceButton1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.gunaAdvenceButton1.Click += new System.EventHandler(this.gunaAdvenceButton1_Click);
            // 
            // gunaPanel3
            // 
            this.gunaPanel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.gunaPanel3.Controls.Add(this.PictureBox2);
            this.gunaPanel3.Location = new System.Drawing.Point(2, 230);
            this.gunaPanel3.Name = "gunaPanel3";
            this.gunaPanel3.Size = new System.Drawing.Size(133, 164);
            this.gunaPanel3.TabIndex = 45;
            // 
            // PictureBox2
            // 
            this.PictureBox2.BaseColor = System.Drawing.Color.White;
            this.PictureBox2.Location = new System.Drawing.Point(0, 0);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(133, 164);
            this.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox2.TabIndex = 0;
            this.PictureBox2.TabStop = false;
            // 
            // Add
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(729, 516);
            this.Controls.Add(this.gunaPanel2);
            this.Controls.Add(this.gunaNumeric3);
            this.Controls.Add(this.gunaLabel10);
            this.Controls.Add(this.gunaNumeric2);
            this.Controls.Add(this.gunaNumeric1);
            this.Controls.Add(this.TextBoxDiscription);
            this.Controls.Add(this.gunaLabel5);
            this.Controls.Add(this.ComboBoxSeller);
            this.Controls.Add(this.ComboBoxTio);
            this.Controls.Add(this.gunaLabel19);
            this.Controls.Add(this.gunaLabel18);
            this.Controls.Add(this.ComboBox1);
            this.Controls.Add(this.gunaLabel17);
            this.Controls.Add(this.TextBoxPrice30);
            this.Controls.Add(this.gunaLabel15);
            this.Controls.Add(this.TextBoxPhone);
            this.Controls.Add(this.gunaLabel14);
            this.Controls.Add(this.TextBoxPrice);
            this.Controls.Add(this.gunaLabel8);
            this.Controls.Add(this.gunaLabel11);
            this.Controls.Add(this.TextBox1);
            this.Controls.Add(this.TextBox2);
            this.Controls.Add(this.gunaLabel2);
            this.Controls.Add(this.gunaLabel12);
            this.Controls.Add(this.gunaLabel3);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.TextBoxAdress);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.gunaLabel9);
            this.Controls.Add(this.gunaLabel6);
            this.Controls.Add(this.TextBoxNameSell);
            this.Controls.Add(this.gunaLabel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add";
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Add_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Add_MouseMove);
            this.gunaPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox)).EndInit();
            this.gunaPanel2.ResumeLayout(false);
            this.gunaPanel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            this.gunaPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            this.gunaPanel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI.WinForms.GunaElipse gunaElipse1;
        private Guna.UI.WinForms.GunaTextBox TextBoxPrice;
        private Guna.UI.WinForms.GunaLabel gunaLabel8;
        private Guna.UI.WinForms.GunaTextBox TextBox1;
        private Guna.UI.WinForms.GunaTextBox TextBox2;
        private Guna.UI.WinForms.GunaLabel gunaLabel12;
        private Guna.UI.WinForms.GunaLabel gunaLabel9;
        private Guna.UI.WinForms.GunaLabel gunaLabel11;
        private Guna.UI.WinForms.GunaLabel gunaLabel2;
        private Guna.UI.WinForms.GunaLabel gunaLabel3;
        private Guna.UI.WinForms.GunaLabel gunaLabel4;
        public Guna.UI.WinForms.GunaTextBox TextBoxAdress;
        private Guna.UI.WinForms.GunaTextBox TextBoxNameSell;
        private Guna.UI.WinForms.GunaPanel gunaPanel1;
        private Guna.UI.WinForms.GunaPictureBox PictureBox;
        public Guna.UI.WinForms.GunaAdvenceButton btnCancel;
        public Guna.UI.WinForms.GunaAdvenceButton btnAdd;
        private Guna.UI.WinForms.GunaTextBox TextBoxDiscription;
        private Guna.UI.WinForms.GunaLabel gunaLabel6;
        private Guna.UI.WinForms.GunaAdvenceButton btnBrowse;
        private Guna.UI.WinForms.GunaComboBox ComboBoxTio;
        private Guna.UI.WinForms.GunaLabel gunaLabel19;
        private Guna.UI.WinForms.GunaLabel gunaLabel18;
        private Guna.UI.WinForms.GunaComboBox ComboBox1;
        private Guna.UI.WinForms.GunaLabel gunaLabel17;
        private Guna.UI.WinForms.GunaTextBox TextBoxPrice30;
        private Guna.UI.WinForms.GunaLabel gunaLabel15;
        private Guna.UI.WinForms.GunaTextBox TextBoxPhone;
        private Guna.UI.WinForms.GunaLabel gunaLabel14;
        private Guna.UI.WinForms.GunaComboBox ComboBoxSeller;
        public Guna.UI.WinForms.GunaLabel gunaLabel5;
        private Guna.UI.WinForms.GunaNumeric gunaNumeric2;
        private Guna.UI.WinForms.GunaNumeric gunaNumeric1;
        private Guna.UI.WinForms.GunaNumeric gunaNumeric3;
        private Guna.UI.WinForms.GunaLabel gunaLabel10;
        private Guna.UI.WinForms.GunaPanel gunaPanel2;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton3;
        private Guna.UI.WinForms.GunaPanel gunaPanel5;
        private Guna.UI.WinForms.GunaPictureBox PictureBox4;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton2;
        private Guna.UI.WinForms.GunaPanel gunaPanel4;
        private Guna.UI.WinForms.GunaPictureBox PictureBox3;
        private Guna.UI.WinForms.GunaAdvenceButton gunaAdvenceButton1;
        private Guna.UI.WinForms.GunaPanel gunaPanel3;
        private Guna.UI.WinForms.GunaPictureBox PictureBox2;
    }
}